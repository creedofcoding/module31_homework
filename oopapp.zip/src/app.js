import "bootstrap/dist/css/bootstrap.min.css";
import "./styles/style.css";
import taskFieldTemplate from "./templates/taskField.html";
import noAccessTemplate from "./templates/noAccess.html";
import { User } from "./models/User";
import { generateTestUser } from "./utils";
import { State } from "./state";
import { authUser } from "./services/auth";

export const appState = new State();

let loginForm;
let contentElement;
let logoutButton;

// Функция для отображения контента авторизованного пользователя
function showAuthenticatedContent() {
  contentElement.innerHTML = taskFieldTemplate;
  loginForm.style.display = 'none';
  logoutButton.style.display = 'block';
}

// Функция для отображения контента неавторизованного пользователя
function showUnauthenticatedContent() {
  contentElement.innerHTML = "Please Sign In to see your tasks!";
  loginForm.style.display = 'flex';
  logoutButton.style.display = 'none';
}

// Функция для проверки авторизации пользователя
function checkAuth() {
  const currentUser = JSON.parse(localStorage.getItem('currentUser'));
  if (currentUser && currentUser.length > 0) {
    const { login, password } = currentUser[0];
    if (authUser(login, password)) {
      showAuthenticatedContent();
      return;
    }
  }
  showUnauthenticatedContent();
}

// Обработчик входа
function handleLogin(e) {
  e.preventDefault();
  const formData = new FormData(loginForm);
  const login = formData.get("login");
  const password = formData.get("password");

  if (authUser(login, password)) {
    localStorage.setItem('currentUser', JSON.stringify([{ login, password }]));
    showAuthenticatedContent();
  } else {
    contentElement.innerHTML = noAccessTemplate;
  }
}

// Обработчик выхода
function handleLogout() {
  localStorage.removeItem('currentUser');
  showUnauthenticatedContent();
}

// Функция инициализации приложения
function initializeApp() {
  loginForm = document.querySelector("#app-login-form");
  contentElement = document.querySelector("#content");
  logoutButton = document.querySelector("#app-logout-btn");

  generateTestUser(User);

  loginForm.addEventListener("submit", handleLogin);
  logoutButton.addEventListener("click", handleLogout);

  checkAuth();
}

initializeApp();